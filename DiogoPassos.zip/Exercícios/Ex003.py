# EX003
"""
Cria um programa que some dois números introduzidos pelo utilizador.
"""


numero_a = int(input("Digite o primeiro número"))
numero_b = int(input("Digite o segundo número"))
resultado = numero_a + numero_b

print(numero_a, "+", numero_b, "=", resultado, "\n\n")