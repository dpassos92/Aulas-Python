# EX002
"""
Cria um programa que mostre uma mensagem de boas vindas ao utilizador.
"""

name = input("Digite o seu nome")

print("Olá", name, "\n\n")