# EX001 (\n) dá parágrafo dentro do print()
"""
Cria um programa simples em Pythonque imprima no ecrã “Olá mundo”
"""

print("Olá Mundo!\n\n")