# EX015
"""
Crie um programa que leia um numero inteiro e mostre se é par ou impar.
"""
num = int(input("Digite um número inteiro\n"))

if num % 2 == 0:
    print("O número é par")
else:
    print("O seu número é impar!")