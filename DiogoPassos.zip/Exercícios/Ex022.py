# EX022
"""
Faça um programa que mostre os números pares entre 1 e 100.
"""

# Mostra os números pares de 1 a 100
for c in range(1,101,2):
    print(c+1)

'''# Alternativa
i = 0
f =100

for c in range(i, f):
    if c == 0:
        continue
    elif c % 2 == 0:
        print(c)'''
